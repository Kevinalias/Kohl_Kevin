# Saját projekt

Ez egy rövid Git-gyakorló projekt a verziókezelés alapjainak bemutatására. A repository README-t, dokumentációt és forrásfájlokat tartalmaz.

## Cél

A Git alapvető munkafolyamatának gyakorlása.

## Fejlesztési ág

A fejlesztes ág változásai össze lettek olvasztva a main ágba.
